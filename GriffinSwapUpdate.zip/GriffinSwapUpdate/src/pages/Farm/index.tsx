import React from 'react'
import './Farm.css'
import Caviar from '../../assets/svg/Group2272.svg';
import Etheriam from '../../assets/svg/Group2270.svg';
import Bitcooin from '../../assets/svg/bit.svg';
import NavCoin from '../../assets/svg/nav.svg';
import Matic from '../../assets/svg/matic.svg';
import Flex from '../../assets/svg/flex.svg';

export default function Farm() {
  // const { chainId } = useActiveWeb3React()
  // const stakingInfos = useStakingInfo()

  // const stakingRewardsExist = Boolean(typeof chainId === 'number' && (STAKING_REWARDS_INFO[chainId]?.length ?? 0) > 0)

  return (
    

      <div className="page-wrapper">
            <div className="farm-page-inner">
                <div className="row">
                    <div className="col-md-4">
                        <div className="cav-cards">
                            <div className="card" >
                                <img className="cavcard-img-top" src={Caviar} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-title cav-amnt">0.000</p>
                                    <div className="card-text">
                                        <p>Deposit Caviar SALP LP</p>
                                        <p>Earn Caviar</p>
                                    </div>
                                    <div className="cav-cd-footer farm-cd-btns">
                                        <a href="#" className="btn btn-primary cav-card-btn">Select</a>
                                        <a href="#" className="btn btn-primary cav-card-btn">Get LP</a>
                                    </div>
                                </div>
                                <div className="cav-cd-bottom">
                                    <span>APY</span>
                                    <span>83:34%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="cav-cards">
                            <div className="card" >
                            <img className="cavcard-img-top" src={Etheriam} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-title cav-amnt">0.000</p>
                                    <div className="card-text">
                                        <p>Deposit Ethereum SALP LP</p>
                                        <p>Earn Ethereum</p>
                                    </div>
                                    <div className="cav-cd-footer farm-cd-btns">
                                        <a href="#" className="btn btn-primary cav-card-btn">Select</a>
                                        <a href="#" className="btn btn-primary cav-card-btn">Get LP</a>
                                    </div>
                                </div>
                                <div className="cav-cd-bottom">
                                    <span>APY</span>
                                    <span>83:34%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="cav-cards">
                            <div className="card" >
                            <img className="cavcard-img-top" src={Bitcooin} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-title cav-amnt">0.000</p>
                                    <div className="card-text">
                                        <p>Deposit Bitcoin SALP LP</p>
                                        <p>Earn Bitcoin</p>
                                    </div>
                                    <div className="cav-cd-footer farm-cd-btns">
                                        <a href="#" className="btn btn-primary cav-card-btn">Select</a>
                                        <a href="#" className="btn btn-primary cav-card-btn">Get LP</a>
                                    </div>
                                </div>
                                <div className="cav-cd-bottom">
                                    <span>APY</span>
                                    <span>83:34%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="cav-cards">
                            <div className="card" >
                            <img className="cavcard-img-top" src={NavCoin} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-title cav-amnt">0.000</p>
                                    <div className="card-text">
                                        <p>Deposit Navcoin SALP LP</p>
                                        <p>Earn Navcoin</p>
                                    </div>
                                    <div className="cav-cd-footer farm-cd-btns">
                                        <a href="#" className="btn btn-primary cav-card-btn">Select</a>
                                        <a href="#" className="btn btn-primary cav-card-btn">Get LP</a>
                                    </div>
                                </div>
                                <div className="cav-cd-bottom">
                                    <span>APY</span>
                                    <span>83:34%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="cav-cards">
                            <div className="card" >
                            <img className="cavcard-img-top" src={Matic} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-title cav-amnt">0.000</p>
                                    <div className="card-text">
                                        <p>Deposit Matic Network SALP LP</p>
                                        <p>Earn Matic Network</p>
                                    </div>
                                    <div className="cav-cd-footer farm-cd-btns">
                                        <a href="#" className="btn btn-primary cav-card-btn">Select</a>
                                        <a href="#" className="btn btn-primary cav-card-btn">Get LP</a>
                                    </div>
                                </div>
                                <div className="cav-cd-bottom">
                                    <span>APY</span>
                                    <span>83:34%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="cav-cards">
                            <div className="card" >
                            <img className="cavcard-img-top" src={Flex} alt="Card image cap" />
                                <div className="card-body">
                                    <p className="card-title cav-amnt">0.000</p>
                                    <div className="card-text">
                                        <p>Deposit Flexacoin SALP LP</p>
                                        <p>Earn Flexacoin</p>
                                    </div>
                                    <div className="cav-cd-footer farm-cd-btns">
                                        <a href="#" className="btn cav-card-btn">Select</a>
                                        <a href="#" className="btn cav-card-btn">Get LP</a>
                                    </div>
                                </div>
                                <div className="cav-cd-bottom">
                                    <span>APY</span>
                                    <span>83:34%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  )
}
