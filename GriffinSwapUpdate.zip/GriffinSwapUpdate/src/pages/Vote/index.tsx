import React from 'react'
import './Vote.css'
export default function Vote() {
  return (
<div className="page-wrapper">
            <div className="vote-page-inner">
                <div className="page-heading">
                    <h2>Proposals</h2>
                    <span>124</span>
                </div>
                <div className="proposals-list">
                    <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li className="nav-item">
                            <a className="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">All</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Pending</a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Closed</a>
                        </li>
                    </ul>
                    <div className="tab-content" id="pills-tabContent">
                        <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>CVCV</h5>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>CAKE distribution to early users of PancakeSwap</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>To simplify voting</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Re-arrange lottery system with reducing jackpot percentage , inc…</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>How to reward those who are truly long-term supporters of FARM C…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                        </div>
                        <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Reduce block emission to 10 CAKE/ BLOCK but increase all APYs by…</h5>
                                    <span className="pending-badg">Pending</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                        </div>
                        <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                            <div className="proposals-sec">
                                <div className="proposal-label">
                                    <h5>Self Governing Betting Section</h5>
                                    <span className="closed-badg">Closed</span>
                                </div>
                                <div className="proposal-dec">#QmSpoDD By 0xc051…b1C1 0.01 CAKEVOTE start 12/4/2020 end 12/25/2020</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

  )
}
