import React from 'react'
import './Earn.css'
import Griffin from '../../assets/svg/Group2272.svg';
import Etheriam from '../../assets/svg/Group2270.svg';


export default function Earn() {
  return (
            <div className="page-wrapper"> 
            <div className="cav-page-inner">
                <div className="top-text-sec">
                    <p>Welcome to the Griffin Bar, Stake Griffin to earn Griffin</p>
                    <a href="#">Click to review the contract</a>
                    <p>38567406.36 Griffin in the whole pool.</p>
                    <p>37301487.76 xGriffin in the whole pool.</p>
                    <p>APY 15.29 %</p>
                    <p>1 xGriffin = 1.034 Griffin</p>
                </div>
                <div className="cav-cards">
                    <div className="card" style={{"width": "18rem"}}>
                        <img className="cavcard-img-top" src={Griffin} alt="Card image cap" />
                        <div className="card-body">
                            <p className="card-title cav-amnt">0.000</p>
                            <div className="card-text">
                                <p>xGriffin(Griffin Bar) Available</p>
                                <p>Equal To: 0.000 Griffin</p>
                            </div>
                            <div className="cav-cd-footer">
                                <a href="#" className="btn btn-primary cav-card-btn">Convert to Griffin</a>
                            </div>
                        </div>
                    </div>

                    <div className="card" style={{"width": "18rem"}}>
                        <img className="cavcard-img-top" src={Etheriam} alt="Card image cap" />
                        <div className="card-body">
                            <p className="card-title cav-amnt">0.000</p>
                            <div className="card-text">
                                <p>xGriffin(Griffin Bar) Available</p>
                            </div>
                            <div className="cav-cd-footer">
                                <a href="#" className="btn btn-primary cav-card-btn ap-ethbtn">Approve Ethereum</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
  )
}
